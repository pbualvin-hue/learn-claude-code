這是一個練習用的凌亂資料夾，裡面的檔案都是假資料，可以放心讓 Claude Code 幫你整理。
做壞了？重新解壓縮 practice-folder.zip 就是全新的一份。